import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import { sequelize, testConnection } from './config/db.js';
import { authenticateToken } from './middleware/auth.js';
import User from './models/User.js';
import { routeLogger, logAllRoutes } from './middleware/routeLogger.js';

// 导入路由
import authRoutes from './routes/auth.js';
import carouselRoutes from './routes/carousel.js';
import servicesRoutes from './routes/services.js';
import statsRoutes from './routes/stats.js';
import whyUsRoutes from './routes/whyUs.js';
import ctaRoutes from './routes/cta.js';
import siteConfigRoutes from './routes/siteConfig.js';
import menuItemsRoutes from './routes/menuItems.js';
import pagesRoutes from './routes/pages.js';
import installRoutes from './routes/install.js';
import footerRoutes from './routes/footer.js'; // 修改导入路径，使用正确的文件名
import changePasswordRoute from './routes/changePassword.js'; // 导入新的密码修改路由
import uploadsRoutes from './routes/uploads.js'; // 导入新的上传路由
import testRoutes from './routes/testRoutes.js'; // 导入额外的测试路由

// 配置环境变量
dotenv.config();

const app = express();
const PORT = process.env.PORT || 8181;

// 中间件配置
app.use(cors({
  origin: 'https://www.aiqji.cn',
  credentials: true
}));
app.use(express.json());

// 添加专门的路由日志调试中间件
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// 静态文件服务
app.use(express.static('public'));
// 修改静态文件路由顺序，将/uploads放在API路由前
app.use('/uploads', express.static('public/uploads'));

// 连接数据库
testConnection();
sequelize.sync({ alter: true })
  .then(() => console.log('数据库模型同步成功'))
  .catch(err => console.error('数据库模型同步失败:', err));

// 基础路由
app.get('/', (req, res) => {
  res.send('爱奇吉API服务器正在运行');
});

// 添加调试端点
app.all('/api/debug-endpoint', (req, res) => {
  console.log('【debug】访问了调试端点');
  console.log('【debug】请求方法:', req.method);
  console.log('【debug】请求头:', req.headers);
  console.log('【debug】请求体:', req.body);
  
  // 返回所有注册的路由信息，帮助调试
  res.status(200).json({
    success: true,
    message: '调试端点正常工作',
    method: req.method,
    registeredRoutes: routeInfo,
    requestInfo: {
      path: req.path,
      method: req.method,
      headers: req.headers,
      body: req.body
    }
  });
});

// 确保uploads路由注册在其他路由之前
console.log('注册上传路由: /api/uploads');
// 修正路由注册方式，确保路径正确匹配
app.use('/api/uploads', uploadsRoutes);
// 为/api/uploads/test路径添加特殊处理
app.get('/api/uploads/test', (req, res) => {
  console.log('直接处理 /api/uploads/test 请求');
  try {
    // 简单版测试API，确保始终响应
    res.status(200).json({
      success: true,
      message: '上传服务测试端点响应成功',
      serverTime: new Date().toISOString(),
      uploadsDir: 'public/uploads'
    });
  } catch (error) {
    res.status(500).json({
      success: false, 
      message: `测试失败: ${error.message}`
    });
  }
});

// 注册密码修改路由 - 放在其他路由之前，确保它不会被覆盖
console.log('注册密码修改路由: /api/change-password');
app.use('/api/change-password', changePasswordRoute);

// 测试认证API - 直接定义在server.js中确保它可用
app.get('/api/auth/test-auth', authenticateToken, (req, res) => {
  console.log('【server.js】测试认证成功，用户ID:', req.user.id);
  res.json({
    success: true,
    message: '认证成功',
    userId: req.user.id
  });
});

// 直接定义密码修改API - 确保它可用
app.put('/api/auth/password', authenticateToken, async (req, res) => {
  try {
    console.log('【server.js】密码修改请求处理中');
    console.log('请求体:', req.body);
    
    const { currentPassword, newPassword } = req.body;
    
    // 验证输入
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ 
        success: false, 
        message: '请提供当前密码和新密码' 
      });
    }
    
    // 密码长度验证
    if (newPassword.length < 6) {
      return res.status(400).json({ 
        success: false, 
        message: '新密码至少需要6个字符' 
      });
    }
    
    // 获取用户
    const user = await User.findByPk(req.user.id);
    if (!user) {
      return res.status(404).json({ 
        success: false, 
        message: '用户不存在' 
      });
    }
    
    // 验证当前密码
    const isMatch = await user.matchPassword(currentPassword);
    if (!isMatch) {
      return res.status(401).json({ 
        success: false, 
        message: '当前密码不正确' 
      });
    }
    
    // 更新密码
    user.password = newPassword;
    await user.save();
    
    console.log('【server.js】密码修改成功');
    
    return res.status(200).json({
      success: true,
      message: '密码修改成功'
    });
  } catch (err) {
    console.error('【server.js】密码修改异常:', err);
    return res.status(500).json({ 
      success: false, 
      message: '服务器错误: ' + (err.message || '未知错误') 
    });
  }
});

// 测试路由处理
app.all('/api/test-route', (req, res) => {
  console.log(`测试路由被访问: ${req.method} /api/test-route`);
  res.json({ 
    success: true, 
    message: '测试路由工作正常', 
    method: req.method,
    headers: req.headers,
    body: req.body
  });
});

// 注册其他API路由
console.log('注册认证路由: /api/auth');
app.use('/api/auth', authRoutes);
app.use('/api/carousel', carouselRoutes);
app.use('/api/services', servicesRoutes);
app.use('/api/stats', statsRoutes);
app.use('/api/whyus', whyUsRoutes);
app.use('/api/cta', ctaRoutes);

// 添加路由日志中间件
app.use('/api/siteconfig', routeLogger);

// 注册网站配置路由
console.log('注册网站配置路由: /api/siteconfig');
app.use('/api/siteconfig', siteConfigRoutes);
app.use('/api/menuitems', menuItemsRoutes);
app.use('/api/pages', pagesRoutes);
app.use('/api/install', installRoutes);
app.use('/api/footer', footerRoutes); // 确保这行正确

// 注册测试路由
console.log('注册测试路由: /api/test');
app.use('/api/test', testRoutes);

// 在启动服务器前，打印所有已注册的路由
console.log('====== 所有路由 ======');
const routeInfo = logAllRoutes(app);
routeInfo.forEach(route => console.log(route));
console.log('====== 路由打印完成 ======');

// 404处理
app.use((req, res) => {
  const path = `${req.method} ${req.path}`;
  console.log(`404错误: ${path}`);
  res.status(404).json({
    success: false,
    message: `路由不存在: ${path}`,
    registeredRoutes: routeInfo
  });
});

// 启动服务器
app.listen(PORT, () => {
  console.log(`服务器运行在端口: ${PORT}`);
});